cat banner.txt | lolcat -p .6


echo -e "\e[0;33m This trick consist of following & Unfollowing celegrams id"
echo -e "special thanks to t.me/nirvan_marg \e[0m"
    			 

			
read -p "Enter Username : " U
		         	
read -p "Enter password :" -s S
		 	 	
python3 ins.py "$U" "$S"

